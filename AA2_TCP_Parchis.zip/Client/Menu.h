#pragma once
#include "GameObject.h"

// -- Acts like a unity prefab, other menus as prefab variants

class Menu : public GameObject
{
public:
	virtual ~Menu() = default;

};